$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$framework = Split-Path $compiler
$refs = @('System.dll','System.Core.dll','System.Drawing.dll','System.Windows.Forms.dll','WPF/UIAutomationClient.dll','WPF/UIAutomationTypes.dll','WPF/WindowsBase.dll')
$compilerArgs = @('/nologo','/target:winexe','/platform:x64','/optimize+','/utf8output',('/out:' + (Join-Path $PSScriptRoot 'CodexFirstOption.exe')))
foreach ($ref in $refs) { $compilerArgs += '/reference:' + (Join-Path $framework $ref) }
$compilerArgs += Join-Path $PSScriptRoot 'Program.cs'
$compilerArgs += Join-Path $PSScriptRoot 'ControlPanel.cs'
& $compiler @compilerArgs
if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
