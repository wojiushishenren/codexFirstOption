using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Automation;
using System.Windows.Forms;
using Microsoft.Win32;

namespace CodexFirstOption {
  internal sealed class Item {
    public string Kind, Name, Value;
    public bool Visible = true, Enabled = true;
    public AutomationElement Element;
  }
  internal static class Rules {
    public static bool IsHeader(Item x) { return x.Kind == "Text" && (x.Name == "问题" || x.Name == "Question"); }
    public static int First(List<Item> a) {
      if (a.Count > 180 || a.Count(x => IsHeader(x) && x.Visible) != 1) return -1;
      if (a.Any(x => x.Kind == "CheckBox" || x.Kind == "Window" || x.Kind == "Menu")) return -1;
      if (!a.Any(x => x.Visible && x.Kind == "Button" && (x.Name == "跳过" || x.Name == "Skip"))) return -1;
      if (!a.Any(x => x.Visible && x.Kind == "Button" && new[]{"发送","Send","继续","Continue"}.Contains(x.Name))) return -1;
      var edits = a.Where(x => x.Visible && x.Kind == "Edit").ToList();
      if (edits.Count != 1 || !new[]{"或自行撰写回复","Or write your own response"}.Contains(edits[0].Name)) return -1;
      if (!edits[0].Enabled) return -1;
      // Electron's TextPattern includes the placeholder and a CR/LF for an empty editor.
      // Only a disabled send action establishes that this is placeholder text, not a draft.
      bool empty=String.IsNullOrWhiteSpace(edits[0].Value);
      bool placeholder=(edits[0].Value??"").TrimEnd('\r','\n')==edits[0].Name &&
        a.Any(x=>x.Kind=="Button"&&x.Visible&&!x.Enabled&&(x.Name=="发送"||x.Name=="Send"));
      if (!empty && !placeholder) return -1;
      var radios = a.Select((x,i) => new {x,i}).Where(p => p.x.Kind == "RadioButton").ToList();
      if (radios.Count < 1 || radios.Count > 12 || radios.Any(p => !p.x.Visible || !p.x.Enabled || String.IsNullOrWhiteSpace(p.x.Name))) return -1;
      return radios[0].i;
    }
  }
  internal sealed class Candidate {
    public IntPtr Window;
    public AutomationElement Card, Target;
    public string Key;
  }
  internal static class Native {
    internal delegate bool EnumProc(IntPtr w, IntPtr l);
    [DllImport("user32.dll")] internal static extern bool EnumWindows(EnumProc cb, IntPtr l);
    [DllImport("user32.dll")] internal static extern bool IsWindowVisible(IntPtr w);
    [DllImport("user32.dll")] internal static extern bool IsIconic(IntPtr w);
    [DllImport("user32.dll")] internal static extern uint GetWindowThreadProcessId(IntPtr w, out uint p);
    [DllImport("kernel32.dll")] internal static extern IntPtr OpenProcess(uint a, bool i, uint p);
    [DllImport("kernel32.dll")] internal static extern bool CloseHandle(IntPtr h);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] internal static extern int GetPackageFamilyName(IntPtr h, ref uint len, StringBuilder name);
    internal static bool IsCodex(IntPtr w) {
      uint pid; GetWindowThreadProcessId(w, out pid);
      IntPtr p = OpenProcess(0x1000, false, pid);
      if (p == IntPtr.Zero) return false;
      try {
        uint n = 256; var b = new StringBuilder((int)n);
        return GetPackageFamilyName(p, ref n, b) == 0 && b.ToString() == "OpenAI.Codex_2p2nqsd0c76g0";
      } finally { CloseHandle(p); }
    }
    internal static List<IntPtr> Windows(bool visibleOnly) {
      var r = new List<IntPtr>();
      EnumWindows(delegate(IntPtr w, IntPtr l) {
        if ((!visibleOnly || (IsWindowVisible(w) && !IsIconic(w))) && IsCodex(w)) r.Add(w);
        return true;
      }, IntPtr.Zero);
      return r;
    }
  }
  internal static class Detector {
    internal static bool IsStale(Exception e){
      var com=e as COMException;
      return e is ElementNotAvailableException || (com!=null&&com.ErrorCode==unchecked((int)0x80040201));
    }
    internal static CacheRequest SnapshotRequest() {
      var request=new CacheRequest();request.TreeScope=TreeScope.Element;
      foreach(var p in new[]{AutomationElement.ControlTypeProperty,AutomationElement.NameProperty,
        AutomationElement.IsOffscreenProperty,AutomationElement.IsEnabledProperty,AutomationElement.BoundingRectangleProperty,
        ValuePattern.ValueProperty})request.Add(p);
      request.Add(ValuePattern.Pattern);return request;
    }
    internal static List<Item> Read(AutomationElement root) {
      var r = new List<Item>();
      AutomationElementCollection all;
      using(SnapshotRequest().Activate())all=root.FindAll(TreeScope.Descendants,Condition.TrueCondition);
      if (all.Count > 180) return r;
      foreach (AutomationElement e in all) {
        var c = e.Cached;
        string val = "";
        if (c.ControlType == ControlType.Edit) {
          object p;
          if (e.TryGetCachedPattern(ValuePattern.Pattern, out p)) val = ((ValuePattern)p).Cached.Value;
          else if (e.TryGetCurrentPattern(TextPattern.Pattern, out p)) val = ((TextPattern)p).DocumentRange.GetText(1000);
          else val = "unknown";
        }
        r.Add(new Item { Kind=c.ControlType.ProgrammaticName.Replace("ControlType.",""), Name=c.Name,
          Visible=!c.IsOffscreen && !c.BoundingRectangle.IsEmpty && c.BoundingRectangle.Width > 0 && c.BoundingRectangle.Height > 0,
          Enabled=c.IsEnabled, Value=val, Element=e });
      }
      return r;
    }
    internal static string Hash(List<Item> a) {
      var s=String.Join("|",a.Where(x=>x.Kind=="Text"||x.Kind=="RadioButton").Select(x=>x.Kind+":"+x.Name));
      using(var h=SHA256.Create()) return BitConverter.ToString(h.ComputeHash(Encoding.UTF8.GetBytes(s))).Replace("-","").Substring(0,24);
    }
    internal static Candidate Match(AutomationElement card, IntPtr w) {
      var a=Read(card); int index=Rules.First(a);
      if(index<0) return null;
      return new Candidate { Window=w, Card=card, Target=a[index].Element,
        Key=w.ToInt64()+":"+Hash(a) };
    }
    internal static List<Candidate> Scan(IntPtr w) {
      for(int attempt=0;attempt<3;attempt++){
        try{return ScanFresh(w);}catch(Exception e){if(!IsStale(e))throw;if(attempt==2)throw new ElementNotAvailableException("The UI changed during the snapshot; reacquire on the next poll.",e);Thread.Sleep(50);}
      }
      return new List<Candidate>();
    }
    static List<Candidate> ScanFresh(IntPtr w) {
      var r=new List<Candidate>();
      var root=AutomationElement.FromHandle(w);
      AutomationElementCollection headers;
      using(SnapshotRequest().Activate())headers=root.FindAll(TreeScope.Descendants,new AndCondition(
        new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Text),
        new OrCondition(new PropertyCondition(AutomationElement.NameProperty,"问题"),new PropertyCondition(AutomationElement.NameProperty,"Question"))));
      foreach(AutomationElement h in headers) {
        if(h.Cached.IsOffscreen) continue;
        AutomationElement p=h;
        for(int i=0;i<9;i++) {
          p=TreeWalker.ControlViewWalker.GetParent(p);
          if(p==null || p.Equals(root)) break;
          var items=Read(p);int index=Rules.First(items);
          Candidate c=index<0?null:new Candidate{Window=w,Card=p,Target=items[index].Element,Key=w.ToInt64()+":"+Hash(items)};
          if(c!=null) { if(!r.Any(x=>x.Key==c.Key))r.Add(c); break; }
          // A complete question shell with a draft/disabled choice is intentionally skipped.
          // Do not walk into the transcript and read unrelated, virtualized messages.
          if(items.Any(x=>Rules.IsHeader(x))&&items.Any(x=>x.Kind=="RadioButton")&&items.Any(x=>x.Kind=="Edit"))break;
        }
      }
      return r;
    }
    internal static bool Click(Candidate c, Action beforeDispatch=null, Func<bool> canDispatch=null) {
      if(!Native.IsCodex(c.Window) || !Native.IsWindowVisible(c.Window) || Native.IsIconic(c.Window)) return false;
      // Reacquire from the native window immediately before input; never reuse the old tree.
      object p=null;bool invoke=false;
      for(int attempt=0;attempt<3;attempt++){
        try{
          var fresh=Scan(c.Window).FirstOrDefault(x=>x.Key==c.Key);
          if(fresh==null)return false;
          invoke=fresh.Target.TryGetCurrentPattern(InvokePattern.Pattern,out p);
          if(!invoke&&!fresh.Target.TryGetCurrentPattern(SelectionItemPattern.Pattern,out p))throw new InvalidOperationException("Option exposes no supported action; no coordinate fallback.");
          break;
        }catch(Exception e){if(!IsStale(e))throw;if(attempt==2)throw new ElementNotAvailableException("The target changed before dispatch.",e);Thread.Sleep(50);}
      }
      if(canDispatch!=null&&!canDispatch())return false;
      if(beforeDispatch!=null)beforeDispatch();
      try{if(invoke)((InvokePattern)p).Invoke();else ((SelectionItemPattern)p).Select();}
      catch(Exception){Program.Log("action-outcome-unknown "+c.Key);throw;}
      Program.Log("clicked-first "+c.Key);
      return true;
    }
  }
  internal sealed class MonitorContext : ApplicationContext {
    readonly NotifyIcon icon;
    readonly System.Windows.Forms.Timer timer;
    readonly ToolStripMenuItem status, pause;
    readonly EventWaitHandle stop;
    readonly EventWaitHandle show;
    internal ControlPanel Panel;
    volatile bool paused, exiting, codexRunning;
    volatile string workerStatus="等待 Codex";
    internal volatile int DetectedCount, ClickedCount;
    internal volatile string LastAction="尚未调用选项", LastError="无", LastScan="等待首次扫描";
    readonly Dictionary<string,DateTime> pending=new Dictionary<string,DateTime>();
    readonly HashSet<string> done=new HashSet<string>();
    readonly Dictionary<string,DateTime> absent=new Dictionary<string,DateTime>();
    DateTime lastErrorLog=DateTime.MinValue;
    volatile int delaySeconds=Settings.Load();
    internal bool IsPaused { get {return paused;} }
    internal bool CodexRunning { get {return codexRunning;} }
    internal int Delay { get {return delaySeconds;} }
    internal string Status { get {return paused?"已暂停自动选择":workerStatus;} }
    internal void TogglePause(){paused=!paused;pause.Checked=paused;Program.Log(paused?"paused":"resumed");}
    internal void SaveDelay(int value){Settings.Save(value);delaySeconds=value;Program.Log("delay-seconds "+value);}
    internal void ShowPanel(){if(Panel==null||Panel.IsDisposed)Panel=new ControlPanel(this);if(!Panel.Visible)Panel.ReloadSettings();Panel.Show();if(Panel.WindowState==FormWindowState.Minimized)Panel.WindowState=FormWindowState.Normal;Panel.Activate();}
    internal void Quit(){ExitThread();}
    public MonitorContext(EventWaitHandle stopEvent, EventWaitHandle showEvent, bool showInitially) {
      stop=stopEvent;show=showEvent;
      status=new ToolStripMenuItem("等待 Codex") { Enabled=false };
      pause=new ToolStripMenuItem("暂停自动选择",null,delegate{TogglePause();});
      var menu=new ContextMenuStrip();
      menu.Items.Add("打开控制面板",null,delegate { ShowPanel(); });
      menu.Items.Add(status);menu.Items.Add(new ToolStripSeparator());menu.Items.Add(pause);
      menu.Items.Add("设置等待时间…",null,delegate { ShowPanel(); });
      menu.Items.Add("打开运行日志",null,delegate{Process.Start("notepad.exe",Program.Quote(Program.LogPath));});
      menu.Items.Add("取消登录自启并退出",null,delegate{Program.RemoveStartup();ExitThread();});
      menu.Items.Add("退出（下次登录仍自动启动）",null,delegate{ExitThread();});
      icon=new NotifyIcon { Icon=SystemIcons.Information, Text="Codex 首选项助手", ContextMenuStrip=menu, Visible=true };
      icon.DoubleClick+=delegate { ShowPanel(); };
      timer=new System.Windows.Forms.Timer {Interval=500};
      timer.Tick+=delegate {
        if(stop.WaitOne(0)) {ExitThread();return;}
        if(show.WaitOne(0))ShowPanel();
        status.Text=paused?"已暂停":workerStatus;
        icon.Text="Codex 首选项助手 · "+status.Text;
        if(Panel!=null&&!Panel.IsDisposed&&Panel.Visible)Panel.RefreshState();
      };
      timer.Start();
      var worker=new Thread(Loop){IsBackground=true,Name="Codex question observer"};
      worker.SetApartmentState(ApartmentState.MTA);worker.Start();
      if(showInitially)ShowPanel();
    }
    void Configure() {
      bool previous=paused;paused=true;
      using(var form=new Form { Text="设置自动选择等待时间",Size=new Size(350,180),StartPosition=FormStartPosition.CenterScreen,
        FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false,TopMost=true }) {
        var label=new Label{Text="识别到问题后等待（秒）：",Left=18,Top=20,Width=250};
        var number=new NumericUpDown{Minimum=1,Maximum=300,Value=delaySeconds,Left=20,Top=50,Width=280};
        var save=new Button{Text="保存",DialogResult=DialogResult.OK,Left=140,Top=92,Width=75};
        var cancel=new Button{Text="取消",DialogResult=DialogResult.Cancel,Left=225,Top=92,Width=75};
        form.Controls.AddRange(new Control[]{label,number,save,cancel});form.AcceptButton=save;form.CancelButton=cancel;
        if(form.ShowDialog()==DialogResult.OK){delaySeconds=(int)number.Value;Settings.Save(delaySeconds);Program.Log("delay-seconds "+delaySeconds);}
      }
      paused=previous;
    }
    void Loop() {
      Program.Log("started");
      while(!exiting) {
        try {
          codexRunning=Native.Windows(false).Count>0;
          if(!codexRunning) {workerStatus="等待 Codex";pending.Clear();done.Clear();absent.Clear();}
          else if(!paused) {
            workerStatus="监测问题中";
            var present=new HashSet<string>();
            foreach(var w in Native.Windows(true)) {
              if(exiting||paused)break;
              foreach(var c in Detector.Scan(w)) {
                present.Add(c.Key);
                if(done.Contains(c.Key))continue;
                DateTime since;
                if(!pending.TryGetValue(c.Key,out since)) {pending[c.Key]=DateTime.UtcNow;DetectedCount++;Program.Log("detected "+c.Key);continue;}
                double remaining=delaySeconds-(DateTime.UtcNow-since).TotalSeconds;
                if(remaining>0){workerStatus="将在 "+Math.Ceiling(remaining)+" 秒后选择第一项";continue;}
                if(paused || exiting)continue;
                if(Detector.Click(c,delegate{done.Add(c.Key);Program.Log("dispatch-first elapsed="+(DateTime.UtcNow-since).TotalSeconds.ToString("F3",System.Globalization.CultureInfo.InvariantCulture)+" "+c.Key);},delegate{return !paused&&!exiting;})){
                  ClickedCount++;LastAction=DateTime.Now.ToString("HH:mm:ss")+" · 已调用第一项";
                }
              }
            }
            foreach(var k in pending.Keys.Where(k=>!present.Contains(k)).ToArray())pending.Remove(k);
            foreach(var k in done.ToArray()){
              if(present.Contains(k)){absent.Remove(k);continue;}
              if(!absent.ContainsKey(k))absent[k]=DateTime.UtcNow;
              else if((DateTime.UtcNow-absent[k]).TotalSeconds>=3){done.Remove(k);absent.Remove(k);}
            }
            if(done.Count>5000) {paused=true;workerStatus="记录已满，请重启助手";}
          } else pending.Clear();
          LastScan=DateTime.Now.ToString("HH:mm:ss");
          LastError="无";
        } catch(ElementNotAvailableException) {
          workerStatus="界面更新中，正在重新获取";
          LastError="控件已更新，本轮已放弃，正在重新获取";
          if((DateTime.UtcNow-lastErrorLog).TotalSeconds>=30){Program.Log("tree-refresh-retry");lastErrorLog=DateTime.UtcNow;}
        } catch(Exception e) {
          workerStatus="暂无法识别，等待重试";LastError=DateTime.Now.ToString("HH:mm:ss")+" · "+e.GetType().Name;
          if((DateTime.UtcNow-lastErrorLog).TotalSeconds>=30){Program.Log("scan-error "+e.GetType().Name);lastErrorLog=DateTime.UtcNow;}
        }
        for(int i=0;i<(codexRunning?5:20)&&!exiting;i++)Thread.Sleep(100);
      }
    }
    protected override void ExitThreadCore() {exiting=true;timer.Stop();if(Panel!=null){Panel.AllowClose=true;Panel.Close();}icon.Visible=false;icon.Dispose();timer.Dispose();Program.Log("stopped");base.ExitThreadCore();}
  }
  internal static class Settings {
    static readonly string PathName=Path.Combine(Program.Base,"delay-seconds.txt");
    internal static int Parse(string s){int n;return Int32.TryParse(s==null?"":s.Trim(),out n)&&n>=1&&n<=300?n:5;}
    internal static int Load(){try{return Parse(File.ReadAllText(PathName));}catch{return 5;}}
    internal static void Save(int n){File.WriteAllText(PathName,n.ToString(),Encoding.UTF8);}
  }
  internal static class Program {
    internal const string RunKey="Software\\Microsoft\\Windows\\CurrentVersion\\Run";
    internal const string AppName="CodexFirstOption";
    static readonly string Session=Process.GetCurrentProcess().SessionId.ToString();
    static readonly string MutexName="Local\\CodexFirstOption-v1-"+Session;
    static readonly string StopName=MutexName+"-stop";
    static readonly string ShowName=MutexName+"-show";
    internal static readonly string Base=AppDomain.CurrentDomain.BaseDirectory;
    internal static readonly string LogPath=Path.Combine(Base,"activity.log");
    static readonly object LogLock=new object();
    internal static string Quote(string s){return "\""+s+"\"";}
    internal static void Log(string s) {try{lock(LogLock){if(File.Exists(LogPath)&&new FileInfo(LogPath).Length>512000)File.WriteAllText(LogPath,"");File.AppendAllText(LogPath,DateTimeOffset.Now.ToString("o")+" "+s+Environment.NewLine,Encoding.UTF8);}}catch{}}
    internal static void RemoveStartup(){using(var k=Registry.CurrentUser.OpenSubKey(RunKey,true)){if(k!=null)k.DeleteValue(AppName,false);}Log("startup-removed");}
    internal static void EnableStartup(){using(var k=Registry.CurrentUser.CreateSubKey(RunKey))k.SetValue(AppName,Quote(Application.ExecutablePath)+" --watch");Log("startup-installed");}
    internal static bool StartupEnabled(){using(var k=Registry.CurrentUser.OpenSubKey(RunKey)){return k!=null && String.Equals(k.GetValue(AppName) as string,Quote(Application.ExecutablePath)+" --watch",StringComparison.OrdinalIgnoreCase);}}
    static void Stop(){try{using(var e=EventWaitHandle.OpenExisting(StopName))e.Set();}catch(WaitHandleCannotBeOpenedException){}}
    [STAThread] static int Main(string[] args) {
      try {
        if(args.Contains("--self-test"))return Tests.Run();
        if(args.Contains("--stop")){Stop();return 0;}
        if(args.Contains("--uninstall")){RemoveStartup();Stop();return 0;}
        if(args.Contains("--probe")) {
          var lines=new List<string>();
          foreach(var w in Native.Windows(true)) {
            lines.Add("verified-codex-window "+w.ToInt64());
            foreach(var c in Detector.Scan(w)) {
              lines.Add("MATCH "+c.Key);
              foreach(var x in Detector.Read(c.Card))lines.Add(x.Kind+" | "+x.Name+" | visible="+x.Visible+" | enabled="+x.Enabled);
            }
          }
          File.WriteAllLines(Path.Combine(Base,"probe.txt"),lines,Encoding.UTF8);return 0;
        }
        if(args.Contains("--install")) {
          EnableStartup();
        }
        bool created;
        using(var mutex=new Mutex(true,MutexName,out created)) {
          if(!created){if(!args.Contains("--watch")){try{using(var e=EventWaitHandle.OpenExisting(ShowName))e.Set();}catch(WaitHandleCannotBeOpenedException){}}return 0;}
          using(var stop=new EventWaitHandle(false,EventResetMode.ManualReset,StopName)) {
           using(var show=new EventWaitHandle(false,EventResetMode.AutoReset,ShowName)) {
            Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MonitorContext(stop,show,!args.Contains("--watch")));
           }
          }
          mutex.ReleaseMutex();
        }
        return 0;
      }catch(Exception e){Log("fatal "+e);if(!args.Contains("--probe")&&!args.Contains("--self-test"))MessageBox.Show("助手未能启动："+e.Message,"Codex 首选项助手");return 1;}
    }
  }
  internal static class Tests {
    static List<Item> Valid(){return new List<Item>{new Item{Kind="Text",Name="问题"},new Item{Kind="Text",Name="请选择颜色"},new Item{Kind="RadioButton",Name="蓝色"},new Item{Kind="RadioButton",Name="绿色"},new Item{Kind="Edit",Name="或自行撰写回复",Value=""},new Item{Kind="Button",Name="跳过"},new Item{Kind="Button",Name="发送",Enabled=false}};}
    internal static int Run(){
      var results=new List<string>();
      Action<string,List<Item>,int> check=(name,items,want)=>{int actual=Rules.First(items);if(actual!=want)throw new Exception(name+": "+actual);results.Add("PASS "+name);};
      check("Chinese question selects first radio",Valid(),2);
      if(!Detector.IsStale(new ElementNotAvailableException())||!Detector.IsStale(new COMException("UIA stale",unchecked((int)0x80040201))))throw new Exception("Stale exception mapping failed");
      results.Add("PASS managed and COM UIA stale errors share recovery");
      if(Detector.IsStale(new COMException("access denied",unchecked((int)0x80070005)))||Detector.IsStale(new InvalidOperationException()))throw new Exception("Non-stale exceptions must not be hidden");
      results.Add("PASS unrelated errors are not treated as stale controls");
      var live=Valid();live[4].Value="或自行撰写回复\r\n";check("real Codex empty TextPattern CRLF placeholder",live,2);
      live=Valid();live[4].Value="或自行撰写回复\n";check("LF placeholder",live,2);
      live=Valid();live[4].Value="或自行撰写回复\r\n";live[6].Enabled=true;check("literal placeholder typed as draft is preserved",live,-1);
      live=Valid();live[4].Value="用户实际回答\r\n";check("TextPattern custom answer is preserved",live,-1);
      live=Valid();live[4].Enabled=false;check("disabled editor rejected",live,-1);
      live=Valid();live[4].Value="unknown";check("unreadable editor rejected",live,-1);
      var a=Valid();a[0].Name="Question";a[4].Name="Or write your own response";a[5].Name="Skip";a[6].Name="Send";check("English question",a,2);
      a=Valid();a[0].Name="权限请求";check("permission header rejected",a,-1);
      a=Valid();a[2].Kind="Button";a[3].Kind="Button";check("approval buttons rejected",a,-1);
      a=Valid();a[4].Value="我正在输入";check("user draft untouched",a,-1);
      a=Valid();a[4].Name="和 Codex 一起工作";check("normal composer rejected",a,-1);
      a=Valid();a[2].Enabled=false;check("disabled first option never skips to second",a,-1);
      a=Valid();a[2].Visible=false;check("hidden first option rejected",a,-1);
      a=Valid();a.RemoveAt(5);check("missing skip rejected",a,-1);
      a=Valid();a.RemoveAt(6);check("missing send rejected",a,-1);
      a=Valid();a.Add(new Item{Kind="Text",Name="问题"});check("multiple cards rejected",a,-1);
      a=Valid();a[2].Kind="CheckBox";check("multi-select rejected",a,-1);
      a=Valid();a.Add(new Item{Kind="Window",Name="确认"});check("nested dialog rejected",a,-1);
      a=Valid();a.RemoveRange(2,2);check("freeform-only question untouched",a,-1);
      a=Valid();a.RemoveAt(3);check("one option supported",a,2);
      a=Valid();for(int i=0;i<181;i++)a.Add(new Item{Kind="Text",Name="history"});check("whole page rejected",a,-1);
      foreach(var entry in new[]{new{Input="",Expected=5},new{Input="0",Expected=5},new{Input="301",Expected=5},new{Input="17",Expected=17},new{Input="invalid",Expected=5}}){if(Settings.Parse(entry.Input)!=entry.Expected)throw new Exception("Delay parse failed");results.Add("PASS delay setting '"+entry.Input+"' -> "+entry.Expected);}
      File.WriteAllLines(Path.Combine(Program.Base,"test-results.txt"),results,Encoding.UTF8);return 0;
    }
  }
}
