using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace CodexFirstOption {
  internal sealed class Card : Panel {
    internal Color Fill=Color.White;
    internal Card(){DoubleBuffered=true;BackColor=Color.Transparent;Padding=new Padding(20);}
    protected override void OnPaint(PaintEventArgs e){
      e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
      var r=new Rectangle(0,0,Width-1,Height-1);int d=24;
      using(var path=new GraphicsPath()){
        path.AddArc(r.Left,r.Top,d,d,180,90);path.AddArc(r.Right-d,r.Top,d,d,270,90);
        path.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);path.AddArc(r.Left,r.Bottom-d,d,d,90,90);path.CloseFigure();
        using(var brush=new SolidBrush(Fill))e.Graphics.FillPath(brush,path);
        using(var pen=new Pen(Color.FromArgb(229,231,238)))e.Graphics.DrawPath(pen,path);
      }
      base.OnPaint(e);
    }
  }
  internal sealed class ControlPanel : Form {
    static readonly Color Ink=Color.FromArgb(29,35,51),Muted=Color.FromArgb(108,116,133),Accent=Color.FromArgb(91,73,219);
    readonly MonitorContext monitor;
    readonly Label state,details,counts,lastAction,lastError,scan,saveNote;
    readonly Button pauseButton;
    readonly NumericUpDown delay;
    readonly CheckBox startup;
    readonly RichTextBox logs;
    DateTime lastLogWrite=DateTime.MinValue;
    internal bool AllowClose;
    static Label TextLabel(string value,float size,Color color,bool bold=false){return new Label{Text=value,Font=new Font("Microsoft YaHei UI",size,bold?FontStyle.Bold:FontStyle.Regular),ForeColor=color,AutoSize=false,BackColor=Color.Transparent,AutoEllipsis=true};}
    static Button ActionButton(string text,bool primary=false){
      var b=new Button{Text=text,Height=38,Width=140,FlatStyle=FlatStyle.Flat,BackColor=primary?Accent:Color.White,
        ForeColor=primary?Color.White:Ink,Cursor=Cursors.Hand,Font=new Font("Microsoft YaHei UI",10),UseVisualStyleBackColor=false};
      b.FlatAppearance.BorderColor=primary?Accent:Color.FromArgb(217,221,231);return b;
    }
    static void Place(Control parent,Control c,int x,int y,int w,int h){c.SetBounds(x,y,w,h);parent.Controls.Add(c);}
    internal ControlPanel(MonitorContext context){
      monitor=context;Text="Codex 首选项助手 · 控制面板";Icon=SystemIcons.Information;
      ClientSize=new Size(960,780);MinimumSize=new Size(870,740);StartPosition=FormStartPosition.CenterScreen;
      BackColor=Color.FromArgb(246,247,251);Font=new Font("Microsoft YaHei UI",10);AutoScaleMode=AutoScaleMode.Font;
      var layout=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(24,18,24,16),ColumnCount=2,RowCount=5,BackColor=BackColor};
      layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));
      foreach(float h in new[]{76f,134f,192f})layout.RowStyles.Add(new RowStyle(SizeType.Absolute,h));
      layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,48));Controls.Add(layout);
      var header=new Panel{Dock=DockStyle.Fill};layout.Controls.Add(header,0,0);layout.SetColumnSpan(header,2);
      Place(header,TextLabel("Codex 首选项助手",23,Ink,true),4,0,600,40);
      Place(header,TextLabel("自动处理问题卡片，让工作继续。",10,Muted),6,46,600,23);
      var version=TextLabel("桌面控制面板  /  v1.2",9,Muted);version.TextAlign=ContentAlignment.TopRight;
      Place(header,version,650,12,248,24);version.Anchor=AnchorStyles.Right|AnchorStyles.Top;
      var live=new Card{Dock=DockStyle.Fill,Margin=new Padding(0,6,0,8),Fill=Color.FromArgb(239,237,255)};
      layout.Controls.Add(live,0,1);layout.SetColumnSpan(live,2);
      state=TextLabel("正在启动…",19,Ink,true);Place(live,state,22,18,650,34);state.Anchor=AnchorStyles.Left|AnchorStyles.Top|AnchorStyles.Right;
      details=TextLabel("",10,Muted);Place(live,details,24,61,650,23);details.Anchor=AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Top;
      counts=TextLabel("",9,Muted);Place(live,counts,24,88,650,22);counts.Anchor=AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Top;
      pauseButton=ActionButton("暂停自动选择",true);Place(live,pauseButton,730,34,154,42);pauseButton.Anchor=AnchorStyles.Right|AnchorStyles.Top;
      pauseButton.Click+=delegate{monitor.TogglePause();RefreshState();};
      var settings=new Card{Dock=DockStyle.Fill,Margin=new Padding(0,6,8,8)};layout.Controls.Add(settings,0,2);
      Place(settings,TextLabel("运行设置",12,Ink,true),20,16,300,28);
      Place(settings,TextLabel("识别后等待",10,Muted),22,58,110,28);
      delay=new NumericUpDown{Minimum=1,Maximum=300,Value=monitor.Delay,Font=new Font("Microsoft YaHei UI",12),AccessibleName="等待秒数"};
      Place(settings,delay,134,56,82,32);Place(settings,TextLabel("秒",10,Muted),224,60,25,26);
      var save=ActionButton("保存时间",true);Place(settings,save,264,54,112,36);
      saveNote=TextLabel("可设为 1–300 秒，保存后生效。",9,Muted);Place(settings,saveNote,22,96,370,24);
      save.Click+=delegate{try{monitor.SaveDelay((int)delay.Value);saveNote.Text="已保存：等待 "+monitor.Delay+" 秒";saveNote.ForeColor=Accent;RefreshState();}catch(Exception e){saveNote.Text="保存失败："+e.Message;saveNote.ForeColor=Color.Firebrick;}};
      startup=new CheckBox{Text="登录 Windows 时自动启动",AutoSize=true,Left=22,Top=133,ForeColor=Ink,Checked=Program.StartupEnabled()};settings.Controls.Add(startup);
      startup.Click+=delegate{try{if(startup.Checked)Program.EnableStartup();else Program.RemoveStartup();}catch(Exception e){startup.Checked=Program.StartupEnabled();MessageBox.Show(this,e.Message,"无法修改启动项");}};
      var behavior=new Card{Dock=DockStyle.Fill,Margin=new Padding(8,6,0,8)};layout.Controls.Add(behavior,1,2);
      Place(behavior,TextLabel("当前行为",12,Ink,true),20,16,320,28);
      Place(behavior,TextLabel("01   只选择问题卡片的第一项",10,Ink),22,55,380,25);
      Place(behavior,TextLabel("02   手动输入时暂停自动选择",10,Ink),22,88,380,25);
      Place(behavior,TextLabel("03   权限授权框不自动处理",10,Ink),22,121,380,25);
      var history=new Card{Dock=DockStyle.Fill,Margin=new Padding(0,6,0,8)};layout.Controls.Add(history,0,3);layout.SetColumnSpan(history,2);
      var historyLayout=new TableLayoutPanel{Dock=DockStyle.Fill,RowCount=4,ColumnCount=1,Margin=Padding.Empty};
      historyLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,34));historyLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,25));historyLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,27));historyLayout.RowStyles.Add(new RowStyle(SizeType.Percent,100));history.Controls.Add(historyLayout);
      var historyHeader=new Panel{Dock=DockStyle.Fill};historyLayout.Controls.Add(historyHeader,0,0);
      Place(historyHeader,TextLabel("本次运行记录",12,Ink,true),0,0,240,28);
      var openLog=ActionButton("打开完整日志");openLog.Size=new Size(132,30);openLog.Dock=DockStyle.Right;historyHeader.Controls.Add(openLog);
      openLog.Click+=delegate{try{System.Diagnostics.Process.Start("notepad.exe",Program.Quote(Program.LogPath));}catch(Exception e){MessageBox.Show(this,e.Message,"日志暂不可用");}};
      lastAction=TextLabel("",9,Muted);lastAction.Dock=DockStyle.Fill;historyLayout.Controls.Add(lastAction,0,1);
      lastError=TextLabel("",9,Muted);lastError.Dock=DockStyle.Fill;historyLayout.Controls.Add(lastError,0,2);
      logs=new RichTextBox{Dock=DockStyle.Fill,ReadOnly=true,BorderStyle=BorderStyle.None,BackColor=Color.FromArgb(248,249,252),ForeColor=Muted,
        Font=new Font("Microsoft YaHei UI",9),DetectUrls=false,WordWrap=true,AccessibleName="运行日志"};historyLayout.Controls.Add(logs,0,3);
      var footer=new Panel{Dock=DockStyle.Fill};layout.Controls.Add(footer,0,4);layout.SetColumnSpan(footer,2);
      scan=TextLabel("",9,Muted);Place(footer,scan,4,13,540,24);scan.Anchor=AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Top;
      var hide=ActionButton("收起到托盘");hide.Click+=delegate{Hide();};Place(footer,hide,620,4,132,36);hide.Anchor=AnchorStyles.Right|AnchorStyles.Top;
      var exit=ActionButton("退出程序");exit.Click+=delegate{monitor.Quit();};Place(footer,exit,764,4,132,36);exit.Anchor=AnchorStyles.Right|AnchorStyles.Top;
      FormClosing+=delegate(object sender,FormClosingEventArgs e){if(!AllowClose&&e.CloseReason==CloseReason.UserClosing){e.Cancel=true;Hide();}};
      RefreshState();
    }
    internal void ReloadSettings(){delay.Value=monitor.Delay;startup.Checked=Program.StartupEnabled();}
    internal void RefreshState(){
      state.Text=monitor.Status;
      state.ForeColor=monitor.IsPaused?Muted:Ink;
      details.Text=(monitor.CodexRunning?"已发现 Codex":"等待 Codex 打开")+"  ·  等待时间 "+monitor.Delay+" 秒  ·  目标：第一项";
      counts.Text="本次运行   检测到 "+monitor.DetectedCount+" 个问题   /   调用选项 "+monitor.ClickedCount+" 次";
      pauseButton.Text=monitor.IsPaused?"恢复自动选择":"暂停自动选择";
      lastAction.Text="最近操作："+monitor.LastAction+"（提交结果以 Codex 回执为准）";
      lastError.Text="最近异常："+monitor.LastError;lastError.ForeColor=monitor.LastError=="无"?Muted:Color.FromArgb(174,104,31);
      scan.Text="上次扫描 "+monitor.LastScan+"  ·  关闭窗口后仍在托盘运行";
      try {
        var modified=File.GetLastWriteTimeUtc(Program.LogPath);
        if(modified!=lastLogWrite){
          lastLogWrite=modified;
          var all=File.ReadAllLines(Program.LogPath);int start=Array.FindLastIndex(all,x=>x.EndsWith(" started"));
          var items=all.Skip(Math.Max(0,start)).Where(x=>x.Length>25&&Char.IsDigit(x[0])).Reverse().Take(35).Select(Describe);
          logs.Text=String.Join(Environment.NewLine,items.ToArray());logs.SelectionStart=0;logs.SelectionLength=0;
        }
      }catch(IOException){}catch(UnauthorizedAccessException){}
    }
    static string Describe(string line){
      int split=line.IndexOf(' ');if(split<0)return line;
      string stamp=line.Substring(0,split),message=line.Substring(split+1);DateTimeOffset time;
      if(DateTimeOffset.TryParse(stamp,out time))stamp=time.ToString("MM-dd HH:mm:ss");
      if(message.StartsWith("clicked-first "))message="已调用第一项，等待 Codex 接受";
      else if(message.StartsWith("dispatch-first "))message="倒计时结束，正在调用第一项";
      else if(message=="tree-refresh-retry")message="界面控件已更新，正在重新获取";
      else if(message.StartsWith("action-outcome-unknown "))message="调用结果不确定，已停止重复点击";
      else if(message.StartsWith("detected "))message="发现问题卡片，开始倒计时";
      else if(message.StartsWith("scan-error "))message="界面识别失败，正在重试 · "+message.Substring(11);
      else if(message.StartsWith("delay-seconds "))message="等待时间已设为 "+message.Substring(14)+" 秒";
      else if(message=="started")message="助手已启动";else if(message=="stopped")message="助手已退出";
      else if(message=="paused")message="自动选择已暂停";else if(message=="resumed")message="自动选择已恢复";
      else if(message=="startup-installed")message="已启用登录自启";else if(message=="startup-removed")message="已取消登录自启";
      return stamp+"    "+message;
    }
  }
}
